import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../services/auth_service.dart';

class PantauAntreanPage extends StatefulWidget {
  final String? antreanId;

  const PantauAntreanPage({
    super.key,
    this.antreanId,
  });

  @override
  State<PantauAntreanPage> createState() =>
      _PantauAntreanPageState();
}

class _PantauAntreanPageState extends State<PantauAntreanPage> {
  bool _isLoading = true;
  bool _isCancelling = false;

  String? _error;
  Map<String, dynamic>? _antrean;

  Timer? _refreshTimer;

  static const Color _purple = Color(0xFFB345D6);
  static const Color _pink = Color(0xFFE04FBC);

  @override
  void initState() {
    super.initState();

    _loadAntrean(showLoading: true);

    // Refresh otomatis setiap 5 detik
    _refreshTimer = Timer.periodic(
      const Duration(seconds: 5),
      (_) {
        if (!_isCancelling) {
          _loadAntrean();
        }
      },
    );
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  // =========================================================
  // LOAD DATA ANTREAN
  // =========================================================

  Future<void> _loadAntrean({
    bool showLoading = false,
  }) async {
    final id = widget.antreanId;

    if (id == null || id.trim().isEmpty) {
      if (!mounted) return;

      setState(() {
        _antrean = null;
        _error = 'ID antrean tidak ditemukan.';
        _isLoading = false;
      });

      return;
    }

    if (showLoading && mounted) {
      setState(() {
        _isLoading = true;
        _error = null;
      });
    }

    try {
      final url = '${AuthService.baseUrl}/antrean/$id';

      final response = await AuthService.client
          .get(Uri.parse(url))
          .timeout(const Duration(seconds: 15));

      final decoded = jsonDecode(response.body);

      if (decoded is! Map) {
        throw Exception('Format respons server tidak valid.');
      }

      if (response.statusCode != 200) {
        throw Exception(
          decoded['message'] ??
              'Gagal mengambil data antrean.',
        );
      }

      if (decoded['success'] == false) {
        throw Exception(
          decoded['message'] ??
              'Data antrean tidak ditemukan.',
        );
      }

      final data = decoded['data'];

      if (data is! Map) {
        throw Exception('Data antrean kosong.');
      }

      final dataAntrean = Map<String, dynamic>.from(data);

      if (!mounted) return;

      setState(() {
        _antrean = dataAntrean;
        _error = null;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _error = e.toString().replaceFirst('Exception: ', '');
        _isLoading = false;
      });
    }
  }

  // =========================================================
  // BATALKAN ANTREAN
  // =========================================================

  Future<void> _batalkanAntrean() async {
    if (_antrean == null ||
        widget.antreanId == null ||
        _isCancelling) {
      return;
    }

    final status = _status.toUpperCase();

    if (status == 'SELESAI' || status == 'BATAL') {
      return;
    }

    final yakin = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Batalkan Antrean?'),
          content: const Text(
            'Apakah kamu yakin ingin membatalkan '
            'antrean ini?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Tidak'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              style: ElevatedButton.styleFrom(
                backgroundColor: _pink,
                foregroundColor: Colors.white,
              ),
              child: const Text('Ya, Batalkan'),
            ),
          ],
        );
      },
    );

    if (yakin != true || !mounted) return;

    setState(() {
      _isCancelling = true;
    });

    try {
      final url =
          '${AuthService.baseUrl}/antrean/'
          '${widget.antreanId}/status';

      final response = await AuthService.client
          .patch(
            Uri.parse(url),
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            },
            body: jsonEncode({
              'status': 'BATAL',
            }),
          )
          .timeout(const Duration(seconds: 15));

      final decoded = jsonDecode(response.body);

      if (response.statusCode < 200 ||
          response.statusCode >= 300) {
        throw Exception(
          decoded is Map
              ? decoded['message'] ??
                  'Gagal membatalkan antrean.'
              : 'Gagal membatalkan antrean.',
        );
      }

      if (decoded is Map &&
          decoded['success'] == false) {
        throw Exception(
          decoded['message'] ??
              'Gagal membatalkan antrean.',
        );
      }

      await _loadAntrean();

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Antrean berhasil dibatalkan.'),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            e.toString().replaceFirst('Exception: ', ''),
          ),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _isCancelling = false;
        });
      }
    }
  }

  // =========================================================
  // DATA ANTREAN
  // =========================================================

  String get _status {
    return (_antrean?['status'] ?? '')
        .toString()
        .toUpperCase();
  }

  String get _statusLabel {
    switch (_status) {
      case 'MENUNGGU':
        return 'Menunggu dipanggil';

      case 'DIPERIKSA':
        return 'Sedang diperiksa';

      case 'SELESAI':
        return 'Pemeriksaan selesai';

      case 'BATAL':
        return 'Antrean dibatalkan';

      default:
        return 'Status antrean';
    }
  }

  String get _nomorAntrean {
    final nomor = _antrean?['noAntrean'];

    if (nomor == null) {
      return '-';
    }

    return 'A-${nomor.toString().padLeft(2, '0')}';
  }

  String get _layanan {
    final peserta = _antrean?['peserta'];

    final kategori = peserta is Map
        ? (peserta['kategori'] ?? '')
            .toString()
            .toUpperCase()
        : '';

    switch (kategori) {
      case 'BALITA':
        return 'Pemeriksaan Balita';

      case 'IBU_HAMIL':
        return 'Pemeriksaan Ibu Hamil';

      case 'LANSIA':
        return 'Pemeriksaan Lansia';

      default:
        return 'Pemeriksaan Posyandu';
    }
  }

  String get _estimasi {
    if (_status == 'DIPERIKSA') {
      return 'Nomor antrean Anda sedang dilayani';
    }

    if (_status == 'SELESAI') {
      return 'Pemeriksaan telah selesai';
    }

    if (_status == 'BATAL') {
      return 'Antrean telah dibatalkan';
    }

    return 'Estimasi menunggu akan diperbarui';
  }

  bool get _bisaDibatalkan {
    return _antrean != null &&
        _status != 'SELESAI' &&
        _status != 'BATAL';
  }

  // =========================================================
  // RESPONSIVE UI
  // =========================================================

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context);

    final screenWidth = media.size.width;
    final screenHeight = media.size.height;

    // Ukuran mengikuti ukuran layar.
    final scale = (screenWidth / 390)
        .clamp(0.85, 1.30)
        .toDouble();

    final horizontalPadding =
        (screenWidth * 0.06)
            .clamp(18.0, 32.0)
            .toDouble();

    // Konten tablet dibatasi agar tidak terlalu lebar.
    final maxContentWidth =
        screenWidth >= 700 ? 600.0 : screenWidth;

    final ticketWidth = screenWidth >= 700
        ? 360.0
        : screenWidth - horizontalPadding * 2;

    final ticketHeight = (screenHeight * 0.18)
        .clamp(120.0, 175.0)
        .toDouble();

    return Scaffold(
      backgroundColor: Colors.white,

      body: Stack(
        children: [
          // Background wave
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: screenHeight * 0.22,
            child: CustomPaint(
              painter: _PantauWavePainter(),
            ),
          ),

          SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                return SingleChildScrollView(
                  physics:
                      const BouncingScrollPhysics(),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minHeight: constraints.maxHeight,
                    ),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: BoxConstraints(
                          maxWidth: maxContentWidth,
                        ),
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(
                            horizontalPadding,
                            8 * scale,
                            horizontalPadding,
                            24 * scale,
                          ),
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              // HEADER
                              _buildHeader(scale),

                              SizedBox(
                                height: 24 * scale,
                              ),

                              // NOMOR ANTREAN
                              Center(
                                child: CustomPaint(
                                  painter:
                                      _PantauTicketPainter(
                                    fillColor: Colors.white,
                                  ),
                                  child: SizedBox(
                                    width: ticketWidth,
                                    height: ticketHeight,
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment
                                              .center,
                                      children: [
                                        Text(
                                          'Nomor Antrean Anda',
                                          textAlign:
                                              TextAlign.center,
                                          style:
                                              GoogleFonts.poppins(
                                            fontSize:
                                                14 * scale,
                                            fontWeight:
                                                FontWeight.w700,
                                            color: Colors.black,
                                          ),
                                        ),

                                        SizedBox(
                                          height: 4 * scale,
                                        ),

                                        FittedBox(
                                          fit: BoxFit.scaleDown,
                                          child: ShaderMask(
                                            shaderCallback:
                                                (bounds) {
                                              return const LinearGradient(
                                                colors: [
                                                  _purple,
                                                  _pink,
                                                ],
                                              ).createShader(
                                                bounds,
                                              );
                                            },
                                            child: Text(
                                              _isLoading
                                                  ? '...'
                                                  : _nomorAntrean,
                                              style:
                                                  GoogleFonts.poppins(
                                                fontSize:
                                                    60 * scale,
                                                fontWeight:
                                                    FontWeight
                                                        .w800,
                                                height: 1.0,
                                                color:
                                                    Colors.white,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),

                              SizedBox(
                                height: 30 * scale,
                              ),

                              // STATUS
                              Text(
                                _statusLabel,
                                style:
                                    GoogleFonts.poppins(
                                  fontSize: 15 * scale,
                                  fontWeight:
                                      FontWeight.w700,
                                  color: Colors.black,
                                ),
                              ),

                              SizedBox(
                                height: 12 * scale,
                              ),

                              _buildStatusWidget(scale),

                              SizedBox(
                                height: 24 * scale,
                              ),

                              // ESTIMASI
                              _buildInfoCard(
                                icon:
                                    Icons.access_time_rounded,
                                title: 'Estimasi Giliran',
                                description: _estimasi,
                                scale: scale,
                              ),

                              SizedBox(
                                height: 14 * scale,
                              ),

                              // INFORMASI
                              _buildInfoCard(
                                icon:
                                    Icons.info_outline_rounded,
                                title: 'Informasi Antrean',
                                description:
                                    'Status antrean diperbarui '
                                    'secara otomatis setiap '
                                    '5 detik.',
                                scale: scale,
                              ),

                              SizedBox(
                                height: 28 * scale,
                              ),

                              // BUTTON CANCEL
                              _buildCancelButton(scale),

                              SizedBox(
                                height: 20 * scale,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // =========================================================
  // HEADER
  // =========================================================

  Widget _buildHeader(double scale) {
    return Row(
      children: [
        SizedBox(
          width: 44 * scale,
          child: IconButton(
            padding: EdgeInsets.zero,
            icon: Icon(
              Icons.arrow_back_rounded,
              size: 28 * scale,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),

        Expanded(
          child: Text(
            'Pantau Antrean',
            textAlign: TextAlign.center,
            style: GoogleFonts.poppins(
              fontSize: 16 * scale,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
        ),

        SizedBox(
          width: 44 * scale,
        ),
      ],
    );
  }

  // =========================================================
  // STATUS WIDGET
  // =========================================================

  Widget _buildStatusWidget(double scale) {
    if (_isLoading) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: CircularProgressIndicator(
            color: _purple,
          ),
        ),
      );
    }

    if (_error != null) {
      return Container(
        width: double.infinity,
        padding: EdgeInsets.all(16 * scale),
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.red.shade300,
          ),
          borderRadius: BorderRadius.circular(
            12 * scale,
          ),
        ),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            Text(
              _error!,
              style: GoogleFonts.poppins(
                fontSize: 13 * scale,
                color: Colors.red.shade700,
              ),
            ),

            SizedBox(height: 8 * scale),

            TextButton(
              onPressed: () {
                _loadAntrean(showLoading: true);
              },
              child: const Text('Coba Lagi'),
            ),
          ],
        ),
      );
    }

    if (_antrean == null) {
      return Text(
        'Belum ada data antrean.',
        style: GoogleFonts.poppins(
          fontSize: 14 * scale,
        ),
      );
    }

    return Row(
      crossAxisAlignment:
          CrossAxisAlignment.center,
      children: [
        CustomPaint(
          painter: _PantauTicketPainter(
            radius: 8,
            notchRadius: 6,
            strokeWidth: 1,
          ),
          child: Container(
            constraints: BoxConstraints(
              minWidth: 90 * scale,
              minHeight: 54 * scale,
            ),
            padding: EdgeInsets.symmetric(
              horizontal: 10 * scale,
            ),
            alignment: Alignment.center,
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                _nomorAntrean,
                style: GoogleFonts.poppins(
                  fontSize: 24 * scale,
                  fontWeight: FontWeight.w700,
                  color: Colors.black,
                ),
              ),
            ),
          ),
        ),

        SizedBox(
          width: 14 * scale,
        ),

        Expanded(
          child: Text(
            _layanan,
            style: GoogleFonts.poppins(
              fontSize: 13 * scale,
              color: Colors.black87,
            ),
          ),
        ),
      ],
    );
  }

  // =========================================================
  // INFORMATION CARD
  // =========================================================

  Widget _buildInfoCard({
    required IconData icon,
    required String title,
    required String description,
    required double scale,
  }) {
    return Container(
      width: double.infinity,
      constraints: BoxConstraints(
        minHeight: 82 * scale,
      ),
      padding: EdgeInsets.symmetric(
        horizontal: 18 * scale,
        vertical: 16 * scale,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(
          color: const Color(0xFF555555),
          width: 0.8,
        ),
        borderRadius: BorderRadius.circular(
          10 * scale,
        ),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: _pink,
            size: 28 * scale,
          ),

          SizedBox(
            width: 16 * scale,
          ),

          Expanded(
            child: Column(
              mainAxisAlignment:
                  MainAxisAlignment.center,
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.poppins(
                    fontSize: 12 * scale,
                    fontWeight: FontWeight.w600,
                    color: Colors.black54,
                  ),
                ),

                SizedBox(
                  height: 3 * scale,
                ),

                Text(
                  description,
                  style: GoogleFonts.poppins(
                    fontSize: 12 * scale,
                    height: 1.4,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // =========================================================
  // CANCEL BUTTON
  // =========================================================

  Widget _buildCancelButton(double scale) {
    final enabled = _bisaDibatalkan &&
        !_isLoading &&
        !_isCancelling;

    return SizedBox(
      width: double.infinity,
      height: (58 * scale).clamp(52.0, 72.0),
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: enabled
              ? const LinearGradient(
                  colors: [
                    _purple,
                    _pink,
                  ],
                )
              : null,
          color: enabled
              ? null
              : Colors.grey.shade400,
          borderRadius: BorderRadius.circular(
            14 * scale,
          ),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: enabled
                ? _batalkanAntrean
                : null,
            borderRadius: BorderRadius.circular(
              14 * scale,
            ),
            child: Center(
              child: _isCancelling
                  ? SizedBox(
                      width: 22 * scale,
                      height: 22 * scale,
                      child:
                          const CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Colors.white,
                      ),
                    )
                  : Text(
                      _status == 'BATAL'
                          ? 'Antrean Dibatalkan'
                          : _status == 'SELESAI'
                              ? 'Antrean Selesai'
                              : 'Batalkan Antrean',
                      style: GoogleFonts.poppins(
                        fontSize: 14 * scale,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

// =============================================================
// WAVE BACKGROUND
// =============================================================

class _PantauWavePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    final rect = Rect.fromLTWH(
      0,
      0,
      w,
      h,
    );

    final base = Path()
      ..moveTo(0, 0)
      ..lineTo(w, 0)
      ..lineTo(w, h * 0.72)
      ..cubicTo(
        w * 0.82,
        h * 0.55,
        w * 0.68,
        h * 0.40,
        w * 0.52,
        h * 0.48,
      )
      ..cubicTo(
        w * 0.32,
        h * 0.60,
        w * 0.18,
        h * 0.75,
        0,
        h * 0.58,
      )
      ..close();

    canvas.drawPath(
      base,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFFE74C82),
            Color(0xFFD72BC5),
            Color(0xFFD52FD0),
          ],
        ).createShader(rect),
    );

    final top = Path()
      ..moveTo(0, 0)
      ..lineTo(w, 0)
      ..cubicTo(
        w * 0.77,
        h * 0.10,
        w * 0.62,
        h * 0.28,
        w * 0.40,
        h * 0.28,
      )
      ..cubicTo(
        w * 0.23,
        h * 0.28,
        w * 0.10,
        h * 0.22,
        0,
        h * 0.20,
      )
      ..close();

    canvas.drawPath(
      top,
      Paint()
        ..color = const Color(0xFFAF21AC)
            .withValues(alpha: 0.45),
    );

    final middle = Path()
      ..moveTo(0, h * 0.30)
      ..cubicTo(
        w * 0.23,
        h * 0.43,
        w * 0.37,
        h * 0.45,
        w * 0.58,
        h * 0.32,
      )
      ..cubicTo(
        w * 0.77,
        h * 0.20,
        w * 0.88,
        h * 0.19,
        w,
        h * 0.24,
      )
      ..lineTo(w, h * 0.46)
      ..cubicTo(
        w * 0.75,
        h * 0.37,
        w * 0.61,
        h * 0.43,
        w * 0.43,
        h * 0.56,
      )
      ..cubicTo(
        w * 0.20,
        h * 0.67,
        w * 0.11,
        h * 0.53,
        0,
        h * 0.44,
      )
      ..close();

    canvas.drawPath(
      middle,
      Paint()
        ..color = const Color(0xFFFF91D0)
            .withValues(alpha: 0.40),
    );

    final bottom = Path()
      ..moveTo(0, h * 0.48)
      ..cubicTo(
        w * 0.21,
        h * 0.72,
        w * 0.40,
        h * 0.62,
        w * 0.61,
        h * 0.49,
      )
      ..cubicTo(
        w * 0.79,
        h * 0.36,
        w * 0.89,
        h * 0.43,
        w,
        h * 0.51,
      )
      ..lineTo(w, h * 0.75)
      ..cubicTo(
        w * 0.85,
        h * 0.59,
        w * 0.72,
        h * 0.40,
        w * 0.53,
        h * 0.49,
      )
      ..cubicTo(
        w * 0.34,
        h * 0.60,
        w * 0.20,
        h * 0.76,
        0,
        h * 0.58,
      )
      ..close();

    canvas.drawPath(
      bottom,
      Paint()
        ..color = const Color(0xFFF58ED3)
            .withValues(alpha: 0.42),
    );
  }

  @override
  bool shouldRepaint(
    covariant _PantauWavePainter oldDelegate,
  ) {
    return false;
  }
}

// =============================================================
// TICKET PAINTER
// =============================================================

class _PantauTicketPainter extends CustomPainter {
  final double radius;
  final double notchRadius;
  final double strokeWidth;
  final Color fillColor;

  _PantauTicketPainter({
    this.radius = 13,
    this.notchRadius = 11,
    this.strokeWidth = 1.3,
    this.fillColor = Colors.white,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    final middle = h / 2;

    final path = Path()
      ..moveTo(radius, 0)
      ..lineTo(w - radius, 0)
      ..quadraticBezierTo(
        w,
        0,
        w,
        radius,
      )
      ..lineTo(
        w,
        middle - notchRadius,
      )
      ..arcToPoint(
        Offset(
          w,
          middle + notchRadius,
        ),
        radius: Radius.circular(
          notchRadius,
        ),
        clockwise: false,
      )
      ..lineTo(
        w,
        h - radius,
      )
      ..quadraticBezierTo(
        w,
        h,
        w - radius,
        h,
      )
      ..lineTo(radius, h)
      ..quadraticBezierTo(
        0,
        h,
        0,
        h - radius,
      )
      ..lineTo(
        0,
        middle + notchRadius,
      )
      ..arcToPoint(
        Offset(
          0,
          middle - notchRadius,
        ),
        radius: Radius.circular(
          notchRadius,
        ),
        clockwise: false,
      )
      ..lineTo(0, radius)
      ..quadraticBezierTo(
        0,
        0,
        radius,
        0,
      )
      ..close();

    canvas.drawShadow(
      path,
      const Color(0x33000000),
      3,
      false,
    );

    canvas.drawPath(
      path,
      Paint()
        ..color = fillColor
        ..style = PaintingStyle.fill,
    );

    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0xFF333333)
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth,
    );
  }

  @override
  bool shouldRepaint(
    covariant _PantauTicketPainter oldDelegate,
  ) {
    return oldDelegate.radius != radius ||
        oldDelegate.notchRadius != notchRadius ||
        oldDelegate.strokeWidth != strokeWidth ||
        oldDelegate.fillColor != fillColor;
  }
}